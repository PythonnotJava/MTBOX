from PyQt5.QtWidgets import QApplication as QApplication
from .CodeViewer import ViewSeletedItemCodes as ViewSeletedItemCodes
from .MT import MatTutorial as MatTutorial
from .Setting import ReSetDiag as ReSetDiag
from .CodeViewer import MTFileTool as MTFileTool
from .TreeItems import BaseTree as BaseTree
from .HomePage import ComingHome as ComingHome

__version__ = "1.0.7"
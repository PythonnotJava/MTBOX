from PyQt5.QtWidgets import QApplication as QApplication
from .CodeViewer import ViewSeletedItemCodes as ViewSeletedItemCodes
from .MT import MatTutorial as MatTutorial
from .Setting import ReSetDiag as ReSetDiag

__version__ = "1.0.6"